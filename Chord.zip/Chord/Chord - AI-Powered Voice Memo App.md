# Chord - AI-Powered Voice Memo App

## Overview

Chord is an innovative voice memo application that leverages artificial intelligence to automatically transcribe, categorize, and organize voice recordings. The app is designed with simplicity in mind, featuring a one-tap recording interface that makes capturing ideas effortless, even in situations where traditional note-taking isn't practical.

## Live Application

**Deployed URL:** https://3dhkilc8xw6z.manus.space

## Key Features

### 🎤 One-Tap Recording
- Instant recording with a single tap
- Large, prominent recording button for easy access
- Visual feedback with pulsing animations during recording
- Real-time recording timer

### 🤖 AI-Powered Processing
- Automatic speech-to-text transcription
- Intelligent categorization of voice memos
- Smart title generation based on content
- Summary extraction for quick overview

### 📱 Mobile-First Design
- Responsive design optimized for mobile devices
- Touch-friendly interface elements
- Minimalist aesthetic focusing on core functionality
- Smooth animations and transitions

### 🗂️ Smart Organization
- Automatic categorization into predefined groups:
  - Project Ideas
  - Work Notes
  - Personal Thoughts
  - Meeting Notes
  - Creative Ideas
  - Learning Notes
  - Daily Reflections
  - Task Reminders
  - Brainstorming
  - Other

### 🔍 Search & Filter
- Full-text search across all recordings
- Filter by categories
- Tabbed interface for different views
- Quick access to focused notes

### ⚙️ Customizable Settings
- Audio quality configuration
- AI processing sensitivity adjustment
- Privacy and data retention controls
- Theme and notification preferences

## Technical Architecture

### Frontend
- **Framework:** React 18 with Vite
- **Styling:** Tailwind CSS with shadcn/ui components
- **Icons:** Lucide React
- **State Management:** React Hooks
- **Audio Recording:** Web Audio API with MediaRecorder

### Backend
- **Framework:** Flask (Python)
- **CORS:** Flask-CORS for cross-origin requests
- **Database:** SQLite with SQLAlchemy
- **File Handling:** Werkzeug for secure file uploads
- **API Design:** RESTful endpoints

### AI Processing (Demo Mode)
- Simulated transcription and categorization
- Random selection from predefined responses
- Realistic processing delays for demonstration

## API Endpoints

### Audio Processing
- `POST /api/process` - Complete audio processing pipeline
- `GET /api/health` - Health check endpoint

### User Management
- `GET /api/users` - User management endpoints
- Standard CRUD operations for user data

## User Interface

### Main Recording Screen
- Clean, centered layout with app branding
- Large circular recording button with gradient styling
- Recording status indicator with timer
- Bottom navigation with three main sections

### Recordings List
- Categorized view with collapsible sections
- Search functionality with real-time filtering
- Card-based design for individual recordings
- Play buttons for audio playback
- Timestamp and duration display

### Settings Screen
- Organized sections for different configuration areas
- Audio quality and format selection
- AI processing sensitivity slider
- Privacy controls with toggle switches
- Data retention period selection

## Design Principles

### Simplicity
- Minimal interface elements
- Focus on essential functionality
- Clear visual hierarchy
- Intuitive navigation patterns

### Accessibility
- High contrast color schemes
- Large touch targets (44px minimum)
- Screen reader compatible
- Keyboard navigation support

### Performance
- Lightweight components
- Efficient state management
- Fast loading times
- Smooth animations

### Mobile Optimization
- Touch-friendly interactions
- One-handed operation support
- Responsive breakpoints
- Native-like experience

## Color Palette

- **Primary Gradient:** Blue (#4A90E2) to Orange (#F5A623)
- **Background:** Clean white (#FFFFFF)
- **Text Primary:** Dark gray (#333333)
- **Text Secondary:** Medium gray (#666666)
- **Accent:** Blue (#4A90E2)

## Typography

- **Font Family:** System fonts (San Francisco on iOS, Roboto on Android)
- **Hierarchy:** Clear distinction between headers, body, and captions
- **Accessibility:** Minimum 16px for body text

## Browser Compatibility

- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+
- Mobile browsers with Web Audio API support

## Privacy & Security

- Local audio processing
- No permanent storage of audio files
- Configurable data retention periods
- CORS-enabled for secure cross-origin requests
- No tracking or analytics

## Future Enhancements

### Real AI Integration
- OpenAI Whisper for speech-to-text
- GPT models for intelligent categorization
- Custom training for domain-specific categorization

### Advanced Features
- Voice commands for hands-free operation
- Multi-language support
- Cloud synchronization
- Collaborative note sharing
- Export functionality (PDF, text, audio)

### Mobile App
- Native iOS and Android applications
- Offline functionality
- Push notifications
- Widget support

## Development Setup

### Prerequisites
- Node.js 18+
- Python 3.11+
- Git

### Frontend Setup
```bash
cd chord-app
pnpm install
pnpm run dev
```

### Backend Setup
```bash
cd chord-backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python src/main.py
```

### Building for Production
```bash
# Frontend
cd chord-app
pnpm run build

# Copy to backend static folder
cp -r dist/* ../chord-backend/src/static/

# Deploy backend
cd ../chord-backend
# Deploy using your preferred method
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, feature requests, or bug reports, please open an issue on the project repository.

---

**Chord** - Capturing ideas has never been this simple.

