import os
import tempfile
from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
from datetime import datetime
import random

audio_bp = Blueprint('audio', __name__)

# Sample categories for demo purposes
CATEGORIES = [
    "Project Ideas",
    "Work Notes", 
    "Personal Thoughts",
    "Meeting Notes",
    "Creative Ideas",
    "Learning Notes",
    "Daily Reflections",
    "Task Reminders",
    "Brainstorming",
    "Other"
]

@audio_bp.route('/process', methods=['POST'])
def process_audio():
    """Simulate audio processing pipeline for demo purposes"""
    try:
        if 'audio' not in request.files:
            return jsonify({'error': 'No audio file provided'}), 400
        
        audio_file = request.files['audio']
        if audio_file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Simulate processing delay
        import time
        time.sleep(1)
        
        # Generate demo transcript and categorization
        demo_transcripts = [
            "I just had an amazing idea for a new mobile app that could revolutionize how people take voice notes",
            "Need to remember to follow up with the client about the project timeline and budget requirements",
            "Feeling really inspired today after reading that book about creativity and innovation",
            "Meeting went well, discussed the quarterly goals and team restructuring plans",
            "Brainstorming session for the marketing campaign was productive, lots of creative concepts",
            "Learning about machine learning algorithms is fascinating, especially neural networks",
            "Reflecting on today's events and how they connect to my long-term goals",
            "Don't forget to pick up groceries and call mom this weekend",
            "Random thoughts about combining AI with voice technology for better user experiences"
        ]
        
        transcript = random.choice(demo_transcripts)
        category = random.choice(CATEGORIES)
        
        # Generate title based on transcript
        title = transcript[:50] + "..." if len(transcript) > 50 else transcript
        
        return jsonify({
            'transcript': transcript,
            'category': category,
            'title': title,
            'summary': transcript[:100] + "..." if len(transcript) > 100 else transcript,
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@audio_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'chord-audio-processing'})

