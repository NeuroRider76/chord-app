import os
import tempfile
from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
import openai
from datetime import datetime

audio_bp = Blueprint('audio', __name__)

# Initialize OpenAI client
client = openai.OpenAI()

@audio_bp.route('/transcribe', methods=['POST'])
def transcribe_audio():
    """Transcribe audio file using OpenAI Whisper"""
    try:
        if 'audio' not in request.files:
            return jsonify({'error': 'No audio file provided'}), 400
        
        audio_file = request.files['audio']
        if audio_file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Save the uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.webm') as temp_file:
            audio_file.save(temp_file.name)
            
            # Transcribe using OpenAI Whisper
            with open(temp_file.name, 'rb') as audio_data:
                transcript = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_data,
                    response_format="text"
                )
            
            # Clean up temporary file
            os.unlink(temp_file.name)
            
            return jsonify({
                'transcript': transcript,
                'timestamp': datetime.now().isoformat()
            })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@audio_bp.route('/categorize', methods=['POST'])
def categorize_text():
    """Categorize transcribed text using OpenAI GPT"""
    try:
        data = request.get_json()
        if not data or 'text' not in data:
            return jsonify({'error': 'No text provided'}), 400
        
        text = data['text']
        
        # Use GPT to categorize the text
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": """You are an AI assistant that categorizes voice memo transcripts. 
                    Analyze the given text and determine the most appropriate category from these options:
                    - Project Ideas
                    - Work Notes
                    - Personal Thoughts
                    - Meeting Notes
                    - Creative Ideas
                    - Learning Notes
                    - Daily Reflections
                    - Task Reminders
                    - Brainstorming
                    - Other
                    
                    Also generate a concise title (max 50 characters) that summarizes the main topic.
                    
                    Respond with a JSON object containing:
                    - category: the selected category
                    - title: a concise title
                    - summary: a brief summary (max 100 characters)
                    """
                },
                {
                    "role": "user",
                    "content": f"Categorize this voice memo transcript: {text}"
                }
            ],
            temperature=0.3
        )
        
        # Parse the response
        result = response.choices[0].message.content
        
        # Try to parse as JSON, fallback to basic categorization
        try:
            import json
            parsed_result = json.loads(result)
            return jsonify(parsed_result)
        except:
            # Fallback categorization
            return jsonify({
                'category': 'Other',
                'title': text[:50] + '...' if len(text) > 50 else text,
                'summary': text[:100] + '...' if len(text) > 100 else text
            })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@audio_bp.route('/process', methods=['POST'])
def process_audio():
    """Complete audio processing pipeline: transcribe + categorize"""
    try:
        if 'audio' not in request.files:
            return jsonify({'error': 'No audio file provided'}), 400
        
        audio_file = request.files['audio']
        if audio_file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Save the uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.webm') as temp_file:
            audio_file.save(temp_file.name)
            
            # Transcribe using OpenAI Whisper
            with open(temp_file.name, 'rb') as audio_data:
                transcript = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_data,
                    response_format="text"
                )
            
            # Clean up temporary file
            os.unlink(temp_file.name)
        
        # Categorize the transcript
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": """You are an AI assistant that categorizes voice memo transcripts. 
                    Analyze the given text and determine the most appropriate category from these options:
                    - Project Ideas
                    - Work Notes
                    - Personal Thoughts
                    - Meeting Notes
                    - Creative Ideas
                    - Learning Notes
                    - Daily Reflections
                    - Task Reminders
                    - Brainstorming
                    - Other
                    
                    Also generate a concise title (max 50 characters) that summarizes the main topic.
                    
                    Respond with a JSON object containing:
                    - category: the selected category
                    - title: a concise title
                    - summary: a brief summary (max 100 characters)
                    """
                },
                {
                    "role": "user",
                    "content": f"Categorize this voice memo transcript: {transcript}"
                }
            ],
            temperature=0.3
        )
        
        # Parse the categorization response
        try:
            import json
            categorization = json.loads(response.choices[0].message.content)
        except:
            # Fallback categorization
            categorization = {
                'category': 'Other',
                'title': transcript[:50] + '...' if len(transcript) > 50 else transcript,
                'summary': transcript[:100] + '...' if len(transcript) > 100 else transcript
            }
        
        return jsonify({
            'transcript': transcript,
            'category': categorization.get('category', 'Other'),
            'title': categorization.get('title', 'Voice Memo'),
            'summary': categorization.get('summary', transcript[:100]),
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

