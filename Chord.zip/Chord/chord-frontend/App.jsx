import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, List, Settings, Play, Pause, Search } from 'lucide-react';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Switch } from './components/ui/switch';
import { Label } from './components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Slider } from './components/ui/slider';
import './App.css';

function App() {
  const [currentView, setCurrentView] = useState('record');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [recordings, setRecordings] = useState([
    {
      id: 1,
      title: "Project brainstorm session",
      transcript: "New app idea for voice memos with AI categorization...",
      category: "Project Ideas",
      duration: "2:35",
      timestamp: "1h ago",
      audioUrl: null
    },
    {
      id: 2,
      title: "Meeting notes Q4 strategy",
      transcript: "Discussed budget allocation and team roles for next quarter...",
      category: "Work Notes",
      duration: "4:10",
      timestamp: "3h ago",
      audioUrl: null
    },
    {
      id: 3,
      title: "Personal reflection",
      transcript: "Dream journal entry about recurring symbols and emotional response...",
      category: "Personal Thoughts",
      duration: "1:15",
      timestamp: "1 day ago",
      audioUrl: null
    }
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [audioChunks, setAudioChunks] = useState([]);
  const intervalRef = useRef(null);

  // Recording functionality
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          setAudioChunks(prev => [...prev, event.data]);
        }
      };

      recorder.onstop = () => {
        stream.getTracks().forEach(track => track.stop());
      };

      setMediaRecorder(recorder);
      recorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      
      intervalRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Unable to access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      mediaRecorder.stop();
      setIsRecording(false);
      clearInterval(intervalRef.current);
      
      // Create a new recording entry
      const newRecording = {
        id: recordings.length + 1,
        title: `Voice memo ${recordings.length + 1}`,
        transcript: "Processing with AI...",
        category: "Uncategorized",
        duration: formatTime(recordingTime),
        timestamp: "Just now",
        audioUrl: null
      };
      
      setRecordings(prev => [newRecording, ...prev]);
      setAudioChunks([]);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const filteredRecordings = recordings.filter(recording =>
    recording.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    recording.transcript.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const groupedRecordings = filteredRecordings.reduce((groups, recording) => {
    const category = recording.category;
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(recording);
    return groups;
  }, {});

  // Main Recording View
  const RecordingView = () => (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 p-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Chord</h1>
        <p className="text-gray-600">AI-Powered Voice Memos</p>
      </div>
      
      {isRecording && (
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center mb-2">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse mr-2"></div>
            <span className="text-gray-600">RECORDING...</span>
          </div>
          <div className="text-2xl font-mono text-gray-800">
            {formatTime(recordingTime)}
          </div>
        </div>
      )}
      
      <div className="relative mb-8">
        <Button
          onClick={isRecording ? stopRecording : startRecording}
          className={`w-32 h-32 rounded-full text-white text-xl font-semibold transition-all duration-300 ${
            isRecording 
              ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
              : 'bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600 shadow-lg hover:shadow-xl'
          }`}
        >
          {isRecording ? <MicOff size={40} /> : <Mic size={40} />}
        </Button>
        
        {isRecording && (
          <div className="absolute inset-0 rounded-full border-4 border-blue-300 animate-ping"></div>
        )}
      </div>
      
      <div className="flex space-x-8">
        <Button
          variant="ghost"
          onClick={() => setCurrentView('record')}
          className="flex flex-col items-center p-4"
        >
          <Mic className="mb-1" size={24} />
          <span className="text-sm">Record</span>
        </Button>
        <Button
          variant="ghost"
          onClick={() => setCurrentView('recordings')}
          className="flex flex-col items-center p-4"
        >
          <List className="mb-1" size={24} />
          <span className="text-sm">Recordings</span>
        </Button>
        <Button
          variant="ghost"
          onClick={() => setCurrentView('settings')}
          className="flex flex-col items-center p-4"
        >
          <Settings className="mb-1" size={24} />
          <span className="text-sm">Settings</span>
        </Button>
      </div>
    </div>
  );

  // Recordings List View
  const RecordingsView = () => (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Recordings</h2>
          <Button
            variant="ghost"
            onClick={() => setCurrentView('record')}
            size="sm"
          >
            Back
          </Button>
        </div>
        
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <Input
              placeholder="Search notes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        
        <Tabs defaultValue="categorized" className="mb-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Notes</TabsTrigger>
            <TabsTrigger value="categorized">Categorized</TabsTrigger>
            <TabsTrigger value="focused">Focused</TabsTrigger>
          </TabsList>
          
          <TabsContent value="categorized" className="space-y-4">
            {Object.entries(groupedRecordings).map(([category, categoryRecordings]) => (
              <div key={category} className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-gray-700 flex items-center">
                    <Badge variant="secondary" className="mr-2 bg-gradient-to-r from-blue-100 to-orange-100">
                      {category}
                    </Badge>
                    <span className="text-sm text-gray-500">({categoryRecordings.length})</span>
                  </h3>
                </div>
                
                {categoryRecordings.map((recording) => (
                  <Card key={recording.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3">
                        <Button variant="ghost" size="sm" className="p-2">
                          <Play size={16} />
                        </Button>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-800 truncate">{recording.title}</h4>
                          <p className="text-sm text-gray-600 line-clamp-2 mt-1">{recording.transcript}</p>
                          <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                            <span>{recording.timestamp}</span>
                            <span>{recording.duration}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ))}
          </TabsContent>
          
          <TabsContent value="all">
            <div className="space-y-2">
              {filteredRecordings.map((recording) => (
                <Card key={recording.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <Button variant="ghost" size="sm" className="p-2">
                        <Play size={16} />
                      </Button>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-gray-800 truncate">{recording.title}</h4>
                        <p className="text-sm text-gray-600 line-clamp-2 mt-1">{recording.transcript}</p>
                        <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                          <span>{recording.timestamp}</span>
                          <span>{recording.duration}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="focused">
            <div className="text-center py-8 text-gray-500">
              <p>No focused notes yet. Star important recordings to see them here.</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );

  // Settings View
  const SettingsView = () => (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Settings</h2>
          <Button
            variant="ghost"
            onClick={() => setCurrentView('record')}
            size="sm"
          >
            Back
          </Button>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardContent className="p-6 space-y-4">
              <h3 className="font-semibold text-gray-800">Audio Quality</h3>
              <div className="space-y-3">
                <div>
                  <Label htmlFor="quality">Sample Rate</Label>
                  <Select defaultValue="44100">
                    <SelectTrigger>
                      <SelectValue placeholder="Select quality" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="22050">22.05 kHz (Voice)</SelectItem>
                      <SelectItem value="44100">44.1 kHz (CD Quality)</SelectItem>
                      <SelectItem value="48000">48 kHz (Professional)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="format">Format</Label>
                  <Select defaultValue="mp3">
                    <SelectTrigger>
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mp3">MP3 (Compressed)</SelectItem>
                      <SelectItem value="wav">WAV (Lossless)</SelectItem>
                      <SelectItem value="flac">FLAC (Lossless)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 space-y-4">
              <h3 className="font-semibold text-gray-800">AI Processing</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="language">Language Detection</Label>
                  <Select defaultValue="auto">
                    <SelectTrigger>
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto-detect</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Spanish</SelectItem>
                      <SelectItem value="fr">French</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sensitivity">Categorization Sensitivity</Label>
                  <Slider
                    defaultValue={[50]}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Low</span>
                    <span>Medium</span>
                    <span>High</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 space-y-4">
              <h3 className="font-semibold text-gray-800">Privacy</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="cloud-sync">Cloud Sync</Label>
                  <Switch id="cloud-sync" defaultChecked />
                </div>
                <div>
                  <Label htmlFor="retention">Data Retention</Label>
                  <Select defaultValue="30">
                    <SelectTrigger>
                      <SelectValue placeholder="Select retention period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 Days</SelectItem>
                      <SelectItem value="30">30 Days</SelectItem>
                      <SelectItem value="90">90 Days</SelectItem>
                      <SelectItem value="forever">Forever</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 space-y-4">
              <h3 className="font-semibold text-gray-800">General</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="notifications">Notifications</Label>
                  <Switch id="notifications" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="dark-mode">Dark Mode</Label>
                  <Switch id="dark-mode" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen">
      {currentView === 'record' && <RecordingView />}
      {currentView === 'recordings' && <RecordingsView />}
      {currentView === 'settings' && <SettingsView />}
    </div>
  );
}

export default App;
